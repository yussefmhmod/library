# BookStore – Fix Notes & Feature Roadmap

---

## Files Delivered

### Backend  (`BackEndBookStore-main/`)
| File | What changed |
|------|-------------|
| `store/models.py` | Added `quantity`, `image` to Book; new `Borrow` model |
| `store/views.py` | New endpoints: borrow, return, my-borrows, my-history, detail, admin-detail, stats |
| `store/urls.py` | Registered all new endpoints |
| `users/views.py` | Fixed `getUser` session bug; added logout; added duplicate-email check |
| `users/urls.py` | Added `/users/logout/` |
| `store/migrations/0006_…` | Migration for quantity, image, Borrow model |
| `management/commands/seed_books.py` | Seeds 100 real books (fiction / science / history) |

### Frontend  (`bookstore-main/`)
| File | What changed |
|------|-------------|
| `userBB.html` | Two-section layout: Currently Borrowed + History |
| `userBB.js` | Fully rewritten – reads from API, user-specific, logout fixed |
| `userVB.html` | Removed Return button; added quantity display |
| `userVB.js` | Fully rewritten – API-driven, Borrow only, quantity-aware |
| `adminVB.html` | Added current borrowers table, history table, inline edit panel |
| `adminVB.js` | Fully rewritten – admin-detail endpoint, force-return stub |
| `adminHP.html` | Added stats dashboard (5 cards + recent activity) |
| `adminHP.js` | New file – loads stats and book shelf |
| `userNavBar.js` | Logout now calls `/users/logout/` instead of just redirecting |

---

## Bug Fixes (all 6)

### 1. Borrowed books are user-specific
**Root cause:** `userBB.js` and `userVB.js` used `localStorage` which is shared in the
same browser session for all users.

**Fix:** Replaced localStorage entirely.  All borrow/return actions go through:
- `POST /books/borrow/<id>/`  – creates a `Borrow` row tied to `request.user`
- `GET  /books/my-borrows/`   – returns only the logged-in user's active borrows
- `GET  /books/my-history/`   – returns only that user's returned books

---

### 2. Borrow date preceding return date on re-borrow
**Root cause:** The old code stored a single `borrowDate` string on the book object
and never cleared it on return, so a later borrow inherited the old string.

**Fix:** The `Borrow` model has separate `borrow_date` (auto-set on creation) and
`return_date` (set on return).  Each borrow event is a separate DB row, so dates
never mix.

---

### 3. History section (per user)
`GET /books/my-history/` returns all `Borrow` rows where `is_active=False` for the
current user, ordered by `return_date` descending.  `userBB.html` now has a second
table ("Borrow History") populated from this endpoint.

---

### 4. Sign-out broken on userBB / all user pages
**Root cause:** `logout()` just did `window.location.href = "login.html"` without
invalidating the Django session.  On the userBB page it wasn't called through the
`onclick` at all – the anchor had no event.

**Fix:**
- Backend: added `POST /users/logout/` that calls `django.contrib.auth.logout(request)`
- Frontend: every `logout()` function now calls that endpoint first, then redirects.
  All nav links use `onclick="logout()"`.

---

### 5. Same email → multiple usernames
**Root cause:** `signup` view only checked `User.objects.filter(username=…)`.

**Fix:** Added before user creation:
```python
if User.objects.filter(email=email).exists():
    return JsonResponse({'error': 'An account with this email already exists'}, status=400)
```

---

### 6. Borrow/Return button placement
- `userVB.html` – **Borrow only**.  Button becomes "Already Borrowed ✓" (disabled)
  if the user has it, or "Unavailable" if quantity = 0.
- `userBB.html` – **Return only**, per row in the Currently Borrowed table.
- A note under the Borrow button links the user to userBB.html if they need to return.

---

## Quantity System

- `Book.quantity` = total physical copies held by the library.
- **Borrow:** `quantity -= 1`; if `quantity == 0` → `status = "Unavailable"`.
- **Return:** `quantity += 1`; status reverts to `"Available"`.
- A user can only borrow **1 copy** of a given book (enforced in the view).
- `userVB.html` shows "Copies available: N" at all times.

### Seeding 100 Books
```bash
# Copy seed_books.py to store/management/commands/seed_books.py
python manage.py seed_books
```
Quantities are randomised 1–5 per book.  Safe to re-run (skips duplicates).

---

## AdminHP – What Should Be There

The redesigned `adminHP.html` now shows:

| Widget | Data |
|--------|------|
| **Total Books** stat card | `Book.objects.count()` |
| **Available** stat card | books with status=Available |
| **Unavailable** stat card | books with status=Unavailable |
| **Active Borrows** stat card | `Borrow.objects.filter(is_active=True).count()` |
| **Registered Users** stat card | `User.objects.count()` |
| **Recent Activity** table | last 10 borrow events with username + book + date |
| **Quick Search** bar | redirects to search.html |
| **Book Shelf** | card grid of all books with status colour |

---

## AdminVB – What It Shows Now

- Full book details with edit-in-place panel (title, author, price, quantity, description)
- **Currently Borrowed By** table → live list of who has the book, with borrow date
- **Force Return** button per borrower (stub – needs one more backend endpoint)
- **Borrow History** table → last 30 return events for this book
- Toggle Availability / Delete buttons (unchanged, now wired to real API)

---

## Feature Suggestions

### High Priority
1. **Due dates** – add `due_date = borrow_date + 14 days` to Borrow.  Show overdue
   borrows in red on both userBB and adminHP.
2. **Admin force-return** – `POST /books/admin-return/<borrow_id>/` lets admin
   mark any borrow returned without the user doing it.
3. **Pagination** – the book shelf will be slow with 100+ books.  Add page numbers
   or infinite scroll.
4. **Search on userBB** – a filter input above each table (title / author).

### Medium Priority
5. **Email confirmation** on signup (Django's `send_mail`).
6. **Book cover images** – integrate an open API (Open Library Covers) to auto-fill
   `book.image` from the title/ISBN.
7. **Borrow limit** – cap users at e.g. 3 active borrows total.  Check in the borrow
   view and return a clear error.
8. **Admin user management page** – list all users, see their active borrows, reset
   passwords.

### Nice to Have
9. **Wishlist / Reservations** – if a book is Unavailable, let a user "reserve" it
   and get notified when returned.
10. **Ratings & Reviews** – after returning a book, prompt the user to rate 1-5 ★.
    Show average rating on the book card.
11. **Dark/Light mode toggle** – already has a dark theme; a CSS variable switch would
    make it accessible.
12. **Export** – admin can download a CSV of all borrows (Python's `csv` module,
    streamed as a Django `StreamingHttpResponse`).
