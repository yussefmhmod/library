"""
Usage:
    python manage.py seed_books

Creates 100 books across fiction / science / history with random quantities.
Safe to run multiple times – skips books that already exist by title.
"""

from django.core.management.base import BaseCommand
import random
from store.models import Book

BOOKS = [
    # ── Fiction ───────────────────────────────────────────────────────────
    ("The Great Gatsby",                    "F. Scott Fitzgerald",   "fiction", 12.99),
    ("To Kill a Mockingbird",               "Harper Lee",            "fiction", 10.99),
    ("1984",                                "George Orwell",         "fiction",  9.99),
    ("Animal Farm",                         "George Orwell",         "fiction",  8.50),
    ("Brave New World",                     "Aldous Huxley",         "fiction", 11.00),
    ("The Catcher in the Rye",             "J.D. Salinger",         "fiction", 10.00),
    ("Lord of the Flies",                   "William Golding",       "fiction",  9.50),
    ("The Alchemist",                       "Paulo Coelho",          "fiction", 11.99),
    ("Fahrenheit 451",                      "Ray Bradbury",          "fiction",  9.99),
    ("The Road",                            "Cormac McCarthy",       "fiction", 13.00),
    ("Crime and Punishment",               "Fyodor Dostoevsky",     "fiction", 14.00),
    ("The Brothers Karamazov",             "Fyodor Dostoevsky",     "fiction", 16.00),
    ("War and Peace",                       "Leo Tolstoy",           "fiction", 18.00),
    ("Anna Karenina",                       "Leo Tolstoy",           "fiction", 15.00),
    ("The Metamorphosis",                   "Franz Kafka",           "fiction",  8.00),
    ("The Trial",                           "Franz Kafka",           "fiction",  9.00),
    ("One Hundred Years of Solitude",      "Gabriel García Márquez","fiction", 14.99),
    ("Love in the Time of Cholera",        "Gabriel García Márquez","fiction", 13.00),
    ("The Old Man and the Sea",            "Ernest Hemingway",      "fiction",  9.00),
    ("A Farewell to Arms",                 "Ernest Hemingway",      "fiction", 10.00),
    ("Moby Dick",                           "Herman Melville",       "fiction", 12.00),
    ("Pride and Prejudice",                "Jane Austen",           "fiction", 10.00),
    ("Sense and Sensibility",              "Jane Austen",           "fiction", 10.00),
    ("Jane Eyre",                           "Charlotte Brontë",      "fiction", 11.00),
    ("Wuthering Heights",                   "Emily Brontë",          "fiction", 10.50),
    ("Great Expectations",                 "Charles Dickens",       "fiction", 11.00),
    ("A Tale of Two Cities",               "Charles Dickens",       "fiction", 11.00),
    ("Oliver Twist",                        "Charles Dickens",       "fiction", 10.00),
    ("The Count of Monte Cristo",          "Alexandre Dumas",       "fiction", 16.00),
    ("Don Quixote",                         "Miguel de Cervantes",   "fiction", 15.00),
    ("The Odyssey",                         "Homer",                 "fiction", 10.00),
    ("The Iliad",                           "Homer",                 "fiction", 10.00),
    ("Les Misérables",                     "Victor Hugo",           "fiction", 17.00),
    ("Madame Bovary",                       "Gustave Flaubert",      "fiction", 11.00),
    ("The Three Musketeers",               "Alexandre Dumas",       "fiction", 13.00),
    ("Journey to the Center of the Earth", "Jules Verne",           "fiction", 10.00),
    ("Twenty Thousand Leagues Under Sea",  "Jules Verne",           "fiction", 10.00),
    ("Around the World in Eighty Days",    "Jules Verne",           "fiction",  9.50),
    ("The Time Machine",                   "H.G. Wells",            "fiction",  8.50),
    ("The War of the Worlds",              "H.G. Wells",            "fiction",  9.00),
    ("Dracula",                             "Bram Stoker",           "fiction", 10.00),
    ("Frankenstein",                        "Mary Shelley",          "fiction",  9.00),
    ("The Picture of Dorian Gray",         "Oscar Wilde",           "fiction", 10.00),
    ("Adventures of Huckleberry Finn",     "Mark Twain",            "fiction",  9.00),
    ("Call of the Wild",                   "Jack London",           "fiction",  8.00),
    ("White Fang",                          "Jack London",           "fiction",  8.50),
    ("The Sound and the Fury",             "William Faulkner",      "fiction", 12.00),
    ("Of Mice and Men",                    "John Steinbeck",        "fiction",  9.00),
    ("East of Eden",                        "John Steinbeck",        "fiction", 14.00),
    ("Grapes of Wrath",                    "John Steinbeck",        "fiction", 13.00),

    # ── Science ───────────────────────────────────────────────────────────
    ("A Brief History of Time",            "Stephen Hawking",       "science", 13.00),
    ("The Selfish Gene",                   "Richard Dawkins",       "science", 12.00),
    ("The Origin of Species",              "Charles Darwin",        "science", 11.00),
    ("Cosmos",                              "Carl Sagan",            "science", 14.00),
    ("Pale Blue Dot",                      "Carl Sagan",            "science", 13.00),
    ("The Double Helix",                   "James D. Watson",       "science", 11.00),
    ("Relativity",                          "Albert Einstein",       "science", 10.00),
    ("The Elegant Universe",               "Brian Greene",          "science", 14.00),
    ("Sapiens",                             "Yuval Noah Harari",     "science", 15.99),
    ("Homo Deus",                           "Yuval Noah Harari",     "science", 15.99),
    ("The Gene",                            "Siddhartha Mukherjee", "science", 16.00),
    ("Surely You're Joking, Mr. Feynman!", "Richard Feynman",      "science", 13.00),
    ("Six Easy Pieces",                    "Richard Feynman",      "science", 11.00),
    ("The Blind Watchmaker",               "Richard Dawkins",       "science", 12.00),
    ("Chaos",                               "James Gleick",          "science", 13.00),
    ("Gödel, Escher, Bach",               "Douglas Hofstadter",   "science", 18.00),
    ("Silent Spring",                      "Rachel Carson",         "science", 11.00),
    ("The Periodic Table",                 "Primo Levi",            "science", 12.00),
    ("What Is Life?",                      "Erwin Schrödinger",    "science", 10.00),
    ("The Emperor's New Mind",             "Roger Penrose",         "science", 17.00),
    ("A Short History of Nearly Everything","Bill Bryson",          "science", 14.00),
    ("The Grand Design",                   "Stephen Hawking",       "science", 14.00),
    ("The Demon-Haunted World",            "Carl Sagan",            "science", 13.00),
    ("Superintelligence",                  "Nick Bostrom",          "science", 15.00),
    ("The Structure of Scientific Revolutions","Thomas Kuhn",      "science", 12.00),

    # ── History ───────────────────────────────────────────────────────────
    ("Guns, Germs, and Steel",             "Jared Diamond",         "history", 15.00),
    ("The Art of War",                     "Sun Tzu",               "history",  7.00),
    ("The Prince",                         "Niccolò Machiavelli",  "history",  8.00),
    ("The Diary of a Young Girl",         "Anne Frank",            "history", 10.00),
    ("A People's History of the United States","Howard Zinn",      "history", 16.00),
    ("The Rise and Fall of the Roman Empire","Edward Gibbon",      "history", 20.00),
    ("The Second World War",              "Winston Churchill",     "history", 22.00),
    ("Napoleon: A Biography",             "Frank McLynn",          "history", 18.00),
    ("Alexander the Great",              "Robin Lane Fox",        "history", 16.00),
    ("Caesar",                             "Adrian Goldsworthy",   "history", 15.00),
    ("The Crusades",                       "Thomas Asbridge",       "history", 17.00),
    ("1776",                               "David McCullough",      "history", 14.00),
    ("The Mongol Empire",                 "Jack Weatherford",      "history", 14.00),
    ("Ancient Egypt",                      "Ian Shaw",              "history", 13.00),
    ("The Ottoman Empire",                "Lord Kinross",          "history", 15.00),
    ("The Byzantine Empire",              "John Julius Norwich",   "history", 16.00),
    ("The Viking World",                  "James Graham-Campbell", "history", 14.00),
    ("Churchill: A Life",                 "Martin Gilbert",        "history", 19.00),
    ("The Cold War",                      "John Lewis Gaddis",     "history", 14.00),
    ("The Rise of Adolf Hitler",          "William L. Shirer",     "history", 18.00),
    ("The Civil War",                     "Shelby Foote",          "history", 20.00),
    ("Killing the Rising Sun",            "Bill O'Reilly",         "history", 14.00),
    ("The Silk Roads",                    "Peter Frankopan",       "history", 16.00),
    ("Genghis Khan and the Making of the Modern World","Jack Weatherford","history", 14.00),
    ("SPQR: A History of Ancient Rome",   "Mary Beard",            "history", 15.00),
]

DESCRIPTIONS = {
    "fiction": "A captivating work of literary fiction that explores the depths of human experience.",
    "science": "A groundbreaking scientific work that illuminates our understanding of the natural world.",
    "history": "A meticulously researched historical account that brings the past vividly to life.",
}


class Command(BaseCommand):
    help = "Seed the database with 100 sample books."

    def handle(self, *args, **options):
        created = 0
        skipped = 0
        for title, author, genre, price in BOOKS:
            if Book.objects.filter(title=title).exists():
                skipped += 1
                continue
            qty = random.randint(1, 5)
            Book.objects.create(
                title=title,
                author=author,
                genre=genre,
                price=price,
                quantity=qty,
                status="Available",
                description=DESCRIPTIONS.get(genre, ""),
                image="",   # add real image URLs later
            )
            created += 1

        self.stdout.write(
            self.style.SUCCESS(
                f"Done. Created {created} books, skipped {skipped} duplicates."
            )
        )
